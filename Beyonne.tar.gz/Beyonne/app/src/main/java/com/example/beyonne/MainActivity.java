package com.example.beyonne;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void OpenBtn_clickHander(View v)
    {
        TextView txt = (TextView)findViewById(R.id.textview1);
        txt.setText("Open Beyonne");
    }

    public void CloseBtn_clickHander(View v)
    {
        TextView txt = (TextView)findViewById(R.id.textview1);
        txt.setText("Close Bruce");
    }
}
