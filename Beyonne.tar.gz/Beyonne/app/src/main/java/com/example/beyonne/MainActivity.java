package com.example.beyonne;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.net.InetAddress;

public class MainActivity extends AppCompatActivity {

    boolean isConnect = true;
    Button ConnectButton;//定义连接按钮
    Button SendButton;//定义发送按钮
    EditText IPEditText;//定义ip输入框
    EditText PortText;//定义端口输入框
    EditText SendEditText;//定义信息输出框
    EditText RecvEditText;//定义信息输入框
    Socket socket = null;//定义socket
    private OutputStream outputStream = null;//定义输出流
    private InputStream inputStream = null;//定义输入流

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ConnectButton = (Button)findViewById(R.id.ConnectBtn);//获得按钮对象
        SendButton = (Button)findViewById(R.id.SendBtn);//获得按钮对象
        IPEditText = (EditText)findViewById(R.id.IP_EditText);//获得ip文本框对象
        PortText = (EditText)findViewById(R.id.Port_EditText);//获得端口文本框按钮对象
        SendEditText = (EditText)findViewById(R.id.Send_EditText);//获得发送消息文本框对象
        RecvEditText = (EditText)findViewById(R.id.Recv_EditText);//获得接收消息文本框对象
    }


    public void ConnectBtn_clickHander(View v)
    {
        if (isConnect==true)
        {
            isConnect = false;
            ConnectButton.setText("断开");
            //启动连接线程
            Connect_Thread connect_Thread = new Connect_Thread();
            connect_Thread.start();
        }
        else
        {
            isConnect = true;
            ConnectButton.setText("连接");
            try
            {
                if (socket.isConnected())
                {
                    if (socket!=null)
                    {
                        socket.close();
                        socket = null;
                    }
                }
            }
            catch (IOException e)
            {
                e.printStackTrace();
            }
        }
    }

    public void SendBtn_clickHander(View v)
    {
        try
        {
            if (socket.isConnected())
            {
                outputStream = socket.getOutputStream();
                outputStream.write(SendEditText.toString().getBytes());
            }
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }

    class Connect_Thread extends Thread
    {
        public void run()
        {
            try
            {
                if (socket==null)//如果已经连接上了，就不再执行连接程序
                {
                    InetAddress ipAddress = InetAddress.getByName(IPEditText.getText().toString());
                    int port = Integer.valueOf(PortText.getText().toString());
                    socket = new Socket(ipAddress,port);
                }
            }
            catch (Exception e)
            {
                e.printStackTrace();
            }
            if (socket!=null)
            if (socket.isConnected())
            {
                //在创建完连接后启动接收线程
                Receive_Thread receive_Thread = new Receive_Thread();
                receive_Thread.start();
            }
        }
    }

    class Receive_Thread extends Thread
    {
        public void run()//重写
        {
            try
            {
                while (true)
                {
                    final byte[] buffer = new byte[1024];
                    inputStream = socket.getInputStream();
                    final int len = inputStream.read(buffer);//数据读出来，并且返回数据的长度
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            RecvEditText.setText(new String(buffer,0,len));
                        }
                    });
                }
            }
            catch (IOException e)
            {
                e.printStackTrace();
            }
        }
    }

    private Boolean OpenFlag=false;

    public void OpenBtn_clickHander(View v)
    {
        TextView txt = (TextView)findViewById(R.id.textview1);
        Button OpenBtn = (Button)findViewById(R.id.OpenBtn);
        if (OpenFlag)
        {
            txt.setText("Open Beyonne");
            OpenBtn.setText("打开");
        }
        else
        {
            txt.setText("Close Bruce");
            OpenBtn.setText("关闭");
        }
        OpenFlag = !OpenFlag;
    }

    public void CloseBtn_clickHander(View v)
    {
        TextView txt = (TextView)findViewById(R.id.textview1);
        Button CloseBtn = (Button)findViewById(R.id.CloseBtn);
        if (OpenFlag)
        {
            txt.setText("Open Beyonne");
            CloseBtn.setText("奔驰");
        }
        else
        {
            txt.setText("Close Bruce");
            CloseBtn.setText("宝马");
        }
        OpenFlag = !OpenFlag;
    }
}
